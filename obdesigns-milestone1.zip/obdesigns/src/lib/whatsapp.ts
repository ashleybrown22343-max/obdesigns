import { business } from "@/data/business";
import { formatPrice, unitLabel } from "@/data/products";
import type { CartLine } from "@/context/CartContext";

export interface OrderDetails {
  fullName: string;
  phone: string;
  address: string;
  cityState: string;
  email?: string;
  note?: string;
}

export interface InquiryDetails {
  fullName: string;
  phone: string;
  location: string;
  serviceNeeded: string;
  description: string;
  budget?: string;
}

function waUrl(message: string) {
  return `https://wa.me/${business.phoneWhatsApp}?text=${encodeURIComponent(message)}`;
}

/** Builds the pre-filled order message and returns a wa.me URL. Never invents a total for price-on-request items. */
export function buildOrderWhatsAppUrl(order: OrderDetails, lines: CartLine[]): string {
  const itemLines = lines.map((l) => {
    const unit = unitLabel(l.unit);
    const unitPriceText = formatPrice(l.unitPrice) + (l.unitPrice !== null ? unit : "");
    const lineTotalText =
      l.unitPrice !== null ? `Line total: ${formatPrice(l.unitPrice * l.quantity)}` : "Line total: price on request";
    return `• ${l.productName} (${l.variantLabel}) x${l.quantity} — ${unitPriceText}\n  ${lineTotalText}`;
  });

  const hasUnknown = lines.some((l) => l.unitPrice === null);
  const subtotal = hasUnknown
    ? "Subtotal: to be confirmed (includes price-on-request item(s))"
    : `Subtotal: ${formatPrice(lines.reduce((s, l) => s + (l.unitPrice ?? 0) * l.quantity, 0))}`;

  const message = [
    `Hello OB Designs & Interiors, I'd like to place an order.`,
    ``,
    `Name: ${order.fullName}`,
    `Phone: ${order.phone}`,
    `Delivery address: ${order.address}`,
    `City/State: ${order.cityState}`,
    order.email ? `Email: ${order.email}` : null,
    ``,
    `Order:`,
    ...itemLines,
    ``,
    subtotal,
    order.note ? `\nNote: ${order.note}` : null,
  ]
    .filter((line): line is string => line !== null)
    .join("\n");

  return waUrl(message);
}

/** Builds the pre-filled project consultation message — kept separate from product ordering per spec §16. */
export function buildInquiryWhatsAppUrl(inquiry: InquiryDetails): string {
  const message = [
    `Hello OB Designs & Interiors, I'd like to request a project consultation.`,
    ``,
    `Name: ${inquiry.fullName}`,
    `Phone: ${inquiry.phone}`,
    `Project location: ${inquiry.location}`,
    `Service needed: ${inquiry.serviceNeeded}`,
    `Description: ${inquiry.description}`,
    inquiry.budget ? `Budget: ${inquiry.budget}` : null,
  ]
    .filter((line): line is string => line !== null)
    .join("\n");

  return waUrl(message);
}
