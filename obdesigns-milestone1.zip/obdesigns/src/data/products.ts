// Product catalog per handover spec §13.
// RULE: never invent names, prices, units or sizes. Unknown price -> priceOnRequest: true.
// Add further confirmed products here as more assets/prices are verified with the client.

export type PriceUnit = "flat" | "per_length" | "per_sqm";

export interface ProductVariant {
  id: string;
  label: string; // e.g. "Standard", "With installation"
  price: number | null; // null when unconfirmed
  unit: PriceUnit;
}

export interface Product {
  id: string;
  name: string;
  category: "Panels" | "Blinds" | "Paint" | "Furniture";
  description?: string;
  image: string; // path under /images/ob/
  variants: ProductVariant[];
  priceOnRequest?: boolean;
}

export const products: Product[] = [
  {
    id: "fluted-panel",
    name: "Fluted Panel",
    category: "Panels",
    image: "/images/ob/hero-curtains.jpg", // placeholder — swap for confirmed product photo in next milestone
    variants: [
      { id: "fluted-panel-standard", label: "Standard", price: 10500, unit: "flat" },
      {
        id: "fluted-panel-installed",
        label: "With installation",
        price: 15000,
        unit: "per_length",
      },
    ],
  },
  {
    id: "window-blinds",
    name: "Window Blinds",
    category: "Blinds",
    image: "/images/ob/hero-curtains.jpg",
    variants: [{ id: "window-blinds-standard", label: "Standard", price: 8500, unit: "flat" }],
  },
  {
    id: "day-night-blinds",
    name: "Day/Night Blinds",
    category: "Blinds",
    image: "/images/ob/hero-curtains.jpg",
    variants: [
      { id: "day-night-blinds-sqm", label: "Per sqm", price: 8500, unit: "per_sqm" },
    ],
  },
  {
    id: "wooden-venetian",
    name: "Wooden Venetian",
    category: "Blinds",
    image: "/images/ob/hero-curtains.jpg",
    variants: [
      { id: "wooden-venetian-sqm", label: "Per sqm", price: 14500, unit: "per_sqm" },
    ],
  },
  {
    id: "new-wave-paint",
    name: "New Wave Paint",
    category: "Paint",
    description: "OB's own manufactured emulsion paint line.",
    image: "/images/ob/hero-curtains.jpg",
    variants: [],
    priceOnRequest: true,
  },
];

export function formatPrice(price: number | null): string {
  if (price === null) return "Price on request";
  return `₦${price.toLocaleString("en-NG")}`;
}

export function unitLabel(unit: PriceUnit): string {
  switch (unit) {
    case "per_length":
      return "/length";
    case "per_sqm":
      return "/sqm";
    default:
      return "";
  }
}
