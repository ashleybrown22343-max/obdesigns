// Confirmed business info only — do not add anything not in the handover spec (§2, §3, §19).

export const business = {
  legalName: "OB Designs & Interiors LTD",
  shortName: "OB Designs",
  address: "67 Adesan Rd, Mowe, Obafemi Owode 110113, Ogun State",
  phoneDisplay: "0813 192 9791",
  phoneWhatsApp: "2348131929791", // international format, no leading zero/plus, for wa.me links
  email: "Obinteriors555@gmail.com",
  yearsActive: 6,
  staff: {
    core: 4,
    contractSkilled: 20, // "more than 20"
  },
  serviceArea: "Nationwide service and nationwide delivery",
  social: {
    facebook: "https://www.facebook.com/share/1BAd2ZoSzp/",
    instagram: null as string | null, // placeholder until real link supplied
    googleBusiness: "https://share.google/bFqBAlLAhKO2Wuk27",
  },
  hours: [
    { day: "Monday", time: "8:00 AM – 5:00 PM" },
    { day: "Tuesday", time: "8:00 AM – 5:00 PM" },
    { day: "Wednesday", time: "8:00 AM – 5:00 PM" },
    { day: "Thursday", time: "8:30 AM – 5:00 PM" },
    { day: "Friday", time: "8:30 AM – 5:00 PM" },
    { day: "Saturday", time: "10:00 AM – 5:00 PM" },
    { day: "Sunday", time: "Closed" },
  ],
} as const;

export const services = [
  {
    group: "Interior Design & Decorating",
    items: [
      "Commercial interior design",
      "Home decor selection",
      "Interior decorating",
      "Living room design",
      "Office space design",
    ],
  },
  {
    group: "Painting & Finishing",
    items: ["Interior painting", "Exterior painting", "POP installations", "3D panels"],
  },
  {
    group: "Windows & Soft Furnishings",
    items: ["Window design", "Curtains & beddings"],
  },
  {
    group: "Paint Manufacturing & Products",
    items: ["Paint manufacturing", "New Wave paint products"],
  },
] as const;

export const whyOB = [
  "Owner personally oversees projects",
  "High-quality paint products sold directly",
  "High-quality products and materials used on every project",
  "Affordable, competitive pricing",
  "Combines manufacturing/product knowledge with applied interior finishing",
  `${business.yearsActive} years of active service`,
  "Nationwide service and delivery",
] as const;

export const aboutOB = `OB Designs and Interiors Limited operates at the intersection of manufacturing and applied interior finishing services, providing real-world insight into product performance. The company has operated successfully in interior and exterior painting, POP installations, and decorative finishes.`;
