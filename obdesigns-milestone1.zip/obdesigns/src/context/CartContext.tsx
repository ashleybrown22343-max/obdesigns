import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { Product, ProductVariant, PriceUnit } from "@/data/products";

export interface CartLine {
  productId: string;
  productName: string;
  variantId: string;
  variantLabel: string;
  unitPrice: number | null; // null = price on request
  unit: PriceUnit;
  quantity: number;
}

interface CartContextValue {
  lines: CartLine[];
  addItem: (product: Product, variant: ProductVariant, quantity: number) => void;
  removeItem: (variantId: string) => void;
  setQuantity: (variantId: string, quantity: number) => void;
  clear: () => void;
  itemCount: number;
  subtotal: number | null; // null if any line has an unknown price
}

const CartContext = createContext<CartContextValue | undefined>(undefined);

const STORAGE_KEY = "obdesigns-cart-v1";

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>(() => {
    if (typeof window === "undefined") return [];
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      return raw ? (JSON.parse(raw) as CartLine[]) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(lines));
    } catch {
      // storage unavailable — cart just won't persist across reloads
    }
  }, [lines]);

  function addItem(product: Product, variant: ProductVariant, quantity: number) {
    setLines((prev) => {
      const existing = prev.find((l) => l.variantId === variant.id);
      if (existing) {
        return prev.map((l) =>
          l.variantId === variant.id ? { ...l, quantity: l.quantity + quantity } : l,
        );
      }
      return [
        ...prev,
        {
          productId: product.id,
          productName: product.name,
          variantId: variant.id,
          variantLabel: variant.label,
          unitPrice: variant.price,
          unit: variant.unit,
          quantity,
        },
      ];
    });
  }

  function removeItem(variantId: string) {
    setLines((prev) => prev.filter((l) => l.variantId !== variantId));
  }

  function setQuantity(variantId: string, quantity: number) {
    setLines((prev) =>
      prev.map((l) => (l.variantId === variantId ? { ...l, quantity: Math.max(1, quantity) } : l)),
    );
  }

  function clear() {
    setLines([]);
  }

  const itemCount = useMemo(() => lines.reduce((sum, l) => sum + l.quantity, 0), [lines]);

  const subtotal = useMemo(() => {
    if (lines.some((l) => l.unitPrice === null)) return null;
    return lines.reduce((sum, l) => sum + (l.unitPrice ?? 0) * l.quantity, 0);
  }, [lines]);

  const value: CartContextValue = {
    lines,
    addItem,
    removeItem,
    setQuantity,
    clear,
    itemCount,
    subtotal,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within a CartProvider");
  return ctx;
}
