// Full product grid, variant selection, cart drawer and WhatsApp checkout
// (spec §13–§15) are built in the ecommerce milestone, on top of the
// products.ts data model and CartContext already in place.
export default function Shop() {
  return (
    <div className="content-wrap section-px py-24">
      <h1 className="font-display text-3xl text-ink">Shop</h1>
      <p className="mt-4 text-ink/60 text-sm">Product catalog — coming in the next milestone.</p>
    </div>
  );
}
