import { business } from "@/data/business";

// Full contact section with click-to-call, WhatsApp, hours table and
// project inquiry form (spec §16, §19) lands in the next milestone.
export default function Contact() {
  return (
    <div className="content-wrap section-px py-24">
      <h1 className="font-display text-3xl text-ink">Contact</h1>
      <p className="mt-4 text-ink/70 text-sm">{business.address}</p>
      <p className="mt-1 text-ink/70 text-sm">{business.phoneDisplay}</p>
      <p className="mt-1 text-ink/70 text-sm">{business.email}</p>
    </div>
  );
}
