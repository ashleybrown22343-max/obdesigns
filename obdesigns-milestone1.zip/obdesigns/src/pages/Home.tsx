import Hero from "@/components/Hero";

// Information architecture per spec §9. Milestone 1 ships Hero only;
// sections 2–12 are added in following milestones as reviewed components —
// anchors are kept here so Nav links already resolve to the right spot.
export default function Home() {
  return (
    <>
      <Hero />

      <section id="work" className="content-wrap section-px py-24 text-ink/50 text-sm">
        Featured work — coming in the next milestone.
      </section>

      <section id="services" className="content-wrap section-px py-24 text-ink/50 text-sm">
        Services — coming in the next milestone.
      </section>

      <section id="about" className="content-wrap section-px py-24 text-ink/50 text-sm">
        About OB — coming in the next milestone.
      </section>
    </>
  );
}
