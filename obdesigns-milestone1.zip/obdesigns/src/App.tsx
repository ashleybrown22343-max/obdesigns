import { Routes, Route } from "react-router-dom";
import Nav from "@/components/Nav";
import Home from "@/pages/Home";
import Shop from "@/pages/Shop";
import Contact from "@/pages/Contact";

// Routing strategy (spec §9/§27): the public experience is a single cohesive
// scroll experience (Home = sections 1–12), with Shop and Contact as their
// own routes since they involve forms/cart state. A cart drawer overlays
// any route rather than becoming its own page (spec §9).
export default function App() {
  return (
    <div className="min-h-screen bg-bone">
      <Nav />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </main>
    </div>
  );
}
