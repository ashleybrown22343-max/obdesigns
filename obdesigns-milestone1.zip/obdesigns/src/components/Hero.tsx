import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { business } from "@/data/business";

// Spec §10: strongest genuine project image, editorial headline, two clear CTAs,
// years/nationwide shown subtly, restrained reveal (no over-animated hero).
export default function Hero() {
  return (
    <section className="relative">
      <div className="content-wrap section-px grid lg:grid-cols-12 gap-10 lg:gap-6 items-center pt-10 pb-16 sm:pt-16 sm:pb-24">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="lg:col-span-6 order-2 lg:order-1"
        >
          <p className="text-xs tracking-wide2 uppercase text-gold-dark mb-4">
            {business.yearsActive} years active · {business.serviceArea}
          </p>
          <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl leading-[1.05] text-ink text-balance">
            Interiors, painting and finishing — done with care, built to last.
          </h1>
          <p className="mt-6 text-base sm:text-lg text-ink/70 max-w-md">
            OB Designs & Interiors brings interior design, painting, POP
            work and our own New Wave paint together under one roof —
            overseen personally from consultation to final delivery.
          </p>

          <div className="mt-8 flex flex-wrap gap-4">
            <a
              href="#work"
              className="inline-flex items-center justify-center px-6 py-3 bg-ink text-bone text-sm tracking-wide hover:bg-ink-soft transition-colors"
            >
              View Our Work
            </a>
            <Link
              to="/shop"
              className="inline-flex items-center justify-center px-6 py-3 border border-ink/20 text-ink text-sm tracking-wide hover:border-ink/40 transition-colors"
            >
              Shop Paint & Finishes
            </Link>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 1.03 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.9, ease: "easeOut" }}
          className="lg:col-span-6 order-1 lg:order-2"
        >
          <div className="relative aspect-[4/5] sm:aspect-[3/4] lg:aspect-[4/5] overflow-hidden bg-ink">
            <img
              src="/images/ob/hero-curtains.jpg"
              alt="Interior finishing by OB Designs & Interiors — black curtain installation"
              className="h-full w-full object-cover"
            />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
