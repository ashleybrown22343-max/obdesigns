# OB Designs & Interiors — website

Built against `OB_Designs_DeepSeek_Handover.docx`. React + Vite + TypeScript +
Tailwind + Framer Motion + Lucide, deployed on Vercel from
`github.com/cresyno/obdesigns`.

## Milestone 1 — done (spec §27)

- Folder structure, design tokens (`tailwind.config.ts`), fonts (Fraunces +
  Inter, loaded in `index.html`)
- Stable asset path: `public/images/ob/`
- Product data model: `src/data/products.ts` — confirmed items/prices from
  spec §13 only; unconfirmed prices are `priceOnRequest`
- Business/contact data model: `src/data/business.ts` — confirmed info from
  spec §2/§3 only
- Cart state model: `src/context/CartContext.tsx` (localStorage-backed, no
  backend, per spec §14)
- WhatsApp message builders: `src/lib/whatsapp.ts` (order + project inquiry,
  kept separate per spec §16)
- Routing: `/` (single-scroll IA), `/shop`, `/contact` — cart is meant to be
  a drawer over any route, not its own page (spec §9)
- Global nav + hero, using the real curtain install photo as the hero image
  and the OB logo mark in the nav

## Not yet built (next milestones)

Sections 2–12 of the IA (featured work, services index, differentiators,
about, before/after, shop grid + cart drawer + checkout, paint story,
process, testimonials, project inquiry form, full contact block, footer).
`Shop.tsx` and `Contact.tsx` are stubs so the app builds and routes cleanly.

## One thing to flag for the client

Some of the supplied blind photos show LV/Gucci monogram prints. Recommend
swapping those for a different in-stock print before they go on the live
site — using counterfeit designer branding is a real legal/IP exposure.

## Run locally

```bash
npm install
npm run dev
```

## Deploy

Push to `main` on `github.com/cresyno/obdesigns` — Vercel is already
connected and will build/deploy automatically. `vercel.json` handles SPA
routing so `/shop` and `/contact` don't 404 on refresh/direct load.
