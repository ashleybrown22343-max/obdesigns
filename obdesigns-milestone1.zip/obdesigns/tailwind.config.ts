import type { Config } from "tailwindcss";

// Design tokens per handover spec §7:
// near-black + warm gold accent + cream/bone + white. Editorial, not "AI luxury".
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: "#0E0D0C", // near-black, not pure #000 (softer, warmer)
          soft: "#1A1816",
        },
        gold: {
          DEFAULT: "#B7913C", // warm gold accent — used sparingly, never glowing
          light: "#D4B472",
          dark: "#8C6D2A",
        },
        bone: {
          DEFAULT: "#F3ECE1", // cream/bone
          light: "#FAF7F2",
        },
        paper: "#FFFFFF",
      },
      fontFamily: {
        // Editorial serif for headings, clean sans for body/UI.
        display: ["Fraunces", "Georgia", "serif"],
        sans: ["Inter", "system-ui", "sans-serif"],
      },
      letterSpacing: {
        wide2: "0.14em",
      },
      maxWidth: {
        content: "1400px",
      },
    },
  },
  plugins: [],
} satisfies Config;
